How to install (grid portfolio)
1) Extract the files into your Pages project public/ folder:
   - portfolio.html
   - grid-portfolio.css
   - grid-portfolio.js
2) Ensure your PDFs live at:
   public/assets/examples/<Project Folder>/<File>.pdf
   (Matches the paths used in portfolio.html.)
3) Commit to main or upload a new deployment.
