
// open lightbox when a doc is clicked
document.querySelectorAll('.docs-grid .doc').forEach(a=>{
  a.addEventListener('click', (e)=>{
    e.preventDefault();
    const src = a.getAttribute('data-src') || a.querySelector('object')?.getAttribute('data');
    const lb = document.querySelector('.lightbox');
    lb.hidden = false;
    const obj = document.getElementById('lb-object');
    const link = document.getElementById('lb-link');
    obj.setAttribute('data', src);
    link.setAttribute('href', src.replace(/#.*$/, '')); // open raw pdf in new tab
  });
});

// close lightbox
document.querySelector('.lb-close')?.addEventListener('click', ()=>document.querySelector('.lightbox').hidden = true);
document.querySelector('.lightbox-backdrop')?.addEventListener('click', ()=>document.querySelector('.lightbox').hidden = true);
document.addEventListener('keydown', (e)=>{ if(e.key==='Escape'){ document.querySelector('.lightbox').hidden = true; }});
