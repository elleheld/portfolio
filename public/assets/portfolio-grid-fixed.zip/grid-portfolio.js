
document.querySelectorAll('.docs-grid .doc').forEach(card=>{
  const obj = card.querySelector('object');
  const base = obj.getAttribute('data');
  const frag = '#zoom=page-width&toolbar=0&navpanes=0&scrollbar=0';
  const previewURL = encodeURI(base) + frag;
  // probe file exists
  fetch(encodeURI(base), {method:'HEAD'}).then(r=>{ if(!r.ok) card.style.display='none'; }).catch(()=>card.style.display='none');
  obj.setAttribute('data', previewURL);
  card.addEventListener('click', e=>{
    e.preventDefault();
    const lb = document.querySelector('.lightbox');
    lb.hidden = false;
    const objLb = document.getElementById('lb-object');
    const link = document.getElementById('lb-link');
    objLb.setAttribute('data', encodeURI(base) + '#zoom=page-width&toolbar=1');
    link.setAttribute('href', encodeURI(base));
  });
});
document.querySelector('.lb-close')?.addEventListener('click', ()=>document.querySelector('.lightbox').hidden=true);
document.querySelector('.lightbox-backdrop')?.addEventListener('click', ()=>document.querySelector('.lightbox').hidden=true);
document.addEventListener('keydown', e=>{ if(e.key==='Escape'){ document.querySelector('.lightbox').hidden=true; }});
