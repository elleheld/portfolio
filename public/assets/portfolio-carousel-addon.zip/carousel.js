
// Tiny carousel controller
document.querySelectorAll('.carousel').forEach((car)=>{
  const track = car.querySelector('.carousel-track');
  const slides = [...car.querySelectorAll('.carousel-slide')];
  const prev = car.querySelector('.carousel-btn.prev');
  const next = car.querySelector('.carousel-btn.next');
  const dots = car.querySelectorAll('.carousel-dots button');
  let idx = 0;
  const go = (i)=>{
    idx = (i + slides.length) % slides.length;
    track.style.transform = `translateX(${-idx*100}%)`;
    dots.forEach((d,j)=>d.setAttribute('aria-current', j===idx ? 'true' : 'false'));
  };
  prev?.addEventListener('click', ()=>go(idx-1));
  next?.addEventListener('click', ()=>go(idx+1));
  dots.forEach((d,j)=>d.addEventListener('click', ()=>go(j)));
  go(0);
});
